package com.example.productservicefakestorepart1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Productservicefakestorepart1Application {

    public static void main(String[] args) {
        SpringApplication.run(Productservicefakestorepart1Application.class, args);
    }

}
