package controllers;

public class CategoryController {
}
