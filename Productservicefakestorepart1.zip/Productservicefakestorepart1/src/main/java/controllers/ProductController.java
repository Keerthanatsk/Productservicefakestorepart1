package controllers;
import models.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import services.ProductService;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.web.client.RestTemplate;
import java.util.ArrayList;
import java.util.List;
import services.fakestoreProductservice;
@RestController
@RequestMapping("/products")
public class ProductController {
    private ProductService prodservice;
@Autowired
    public ProductController (ProductService prodservice)
    {
        this.prodservice=prodservice;
    }
    @GetMapping()
    public List<Product> getAllProducts()
    {
        return new ArrayList<>();
    }
    @GetMapping("/{id}")
    public Product getSingleProduct(@PathVariable("id") Long id)
    {
    return  prodservice.getSingleProduct(id);
    }

    @PostMapping()
    public Product addnewproduct(@RequestBody Product prod)
    {
        Product p=new Product();
        p.setTitle("Toys");
        return p;
    }
}
