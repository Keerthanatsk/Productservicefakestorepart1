package services;

import models.Product;

public interface ProductService {
    Product getSingleProduct(Long id);

}
