package services;

import models.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RequestCallback;
import org.springframework.web.client.RestTemplate;
import dto.fakestoreproductdto;
import models.Categories;

@Service
public class  fakestoreProductservice implements ProductService{
    private RestTemplate restTemplate;
    @Autowired
    public fakestoreProductservice (RestTemplate restTemplate)
    {
        this.restTemplate=restTemplate;
    }
    public Product convertfakestoreproducttoproduct(fakestoreproductdto f)
    {
        Product p=new Product();
        p.setTitle(f.getTitle());
        p.setId(f.getId());
        p.setPrice(f.getPrice());
        p.setDescription(f.getDescription());
        p.setImageurl(f.getImage());
        p.setCategory(new Categories());
        p.getCategory().setName(f.getCategory());

        return p;
    }
    @Override
    public Product getSingleProduct(Long id) {
        fakestoreproductdto ft= restTemplate.getForObject(
                "https://fakestoreapi.com/products/"+id,
                fakestoreproductdto.class );
       return convertfakestoreproducttoproduct(ft);
    }
}
