package config;

import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;
@Configuration
public class applicationconfiguration {
    @Bean
    public RestTemplate createrestemplate()
    {
        //@Resttemplate:  this will allow to talk to 3rd party API's
        return new RestTemplateBuilder().build();

    }
}
