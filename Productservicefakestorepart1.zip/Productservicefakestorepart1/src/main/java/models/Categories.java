package models;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Categories {
    private Long id;
    private String name;
}
