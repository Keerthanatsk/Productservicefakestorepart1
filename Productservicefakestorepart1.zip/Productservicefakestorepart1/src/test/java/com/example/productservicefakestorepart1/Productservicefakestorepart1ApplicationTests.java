package com.example.productservicefakestorepart1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Productservicefakestorepart1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
